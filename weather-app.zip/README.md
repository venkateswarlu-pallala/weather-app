# React Weather App

A simple weather app using React and OpenWeatherMap API.